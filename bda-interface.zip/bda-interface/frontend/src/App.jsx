import { Routes, Route } from 'react-router-dom'
import Navbar from './components/Navbar'
import Home from './components/Home'
import SQL3Page from './components/SQL3Page'
import MongoDBPage from './components/MongoDBPage'
import Modelisation from './components/Modelisation'


export default function App() {
  return (
    <>
      <Navbar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/sql3" element={<SQL3Page />} />
        <Route path="/mongodb" element={<MongoDBPage />} />
        <Route path="/modelisation" element={<Modelisation />} />
  
      </Routes>
    </>
  )
}
