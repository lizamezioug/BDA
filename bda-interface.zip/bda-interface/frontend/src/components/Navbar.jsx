import { Link } from 'react-router-dom';
import './Home.css'; // pour le style

export default function Navbar() {
  return (
    <nav className ="navbar" >
    
      <Link to="/" style={{ margin: '0 1rem' }}>Accueil</Link>
      <Link to="/modelisation" style={{ margin: '0 1rem' }}>Modélisation</Link>
      <Link to="/sql3" style={{ margin: '0 1rem' }}>SQL3</Link>
      <Link to="/mongodb" style={{ margin: '0 1rem' }}>MongoDB</Link>
    </nav>
  );
}
