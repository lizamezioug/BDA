import { useState } from 'react';
import QuestionCard from './QuestionCard';
import dzImage from "../assets/dz.jpg";
import './Home.css';

const questions = [
  {
    title: "Voyages avec problèmes",
    description: "Lister tous les voyages ayant eu une panne ou un retard.",
    requete: `SELECT v.numeroV AS num_voyage,
       v.dateVoyage AS date_voyage,
       mt.abreviation AS moyen_transport,
       DEREF(v.Navette).numeroN AS num_navette,
       v.observation AS probleme
FROM Voyage v,
     MoyenTransport mt
WHERE v.observation IS NOT NULL
AND v.observation != 'RAS'
AND DEREF(v.Navette).MoyenTransportN = REF(mt)`
  },
  {
    title: "Lignes avec station principale",
    description: "Lister les lignes contenant au moins une station principale.",
    requete: `SELECT DISTINCT
    l.codeL AS "Numéro Ligne",
    l.stationDepart AS "Station Départ",
    l.stationArrivee AS "Station Arrivée"
FROM 
    Ligne l
WHERE 
    l.stationDepart IN (SELECT nom FROM Station WHERE type = 'principale')
    OR l.stationArrivee IN (SELECT nom FROM Station WHERE type = 'principale')
ORDER BY l.codeL`
  },
  {
    title: "Top navette janvier 2025",
    description: "Trouver la navette avec le plus de voyages en janvier 2025.",
    requete: `WITH StatsVoyages AS (
    SELECT 
        DEREF(v.Navette).numeroN AS num_navette,
        DEREF(DEREF(v.Navette).MoyenTransportN).abreviation AS type_transport,
        DEREF(v.Navette).anneeMiseEnCirculation AS annee_mise_service,
        COUNT(*) AS nb_voyages
    FROM Voyage v
    WHERE v.dateVoyage BETWEEN TO_DATE('01/01/2025', 'DD/MM/YYYY') 
                          AND TO_DATE('31/01/2025', 'DD/MM/YYYY')
    GROUP BY 
        DEREF(v.Navette).numeroN,
        DEREF(DEREF(v.Navette).MoyenTransportN).abreviation,
        DEREF(v.Navette).anneeMiseEnCirculation
)
SELECT num_navette, type_transport, annee_mise_service, nb_voyages
FROM StatsVoyages
WHERE nb_voyages = (SELECT MAX(nb_voyages) FROM StatsVoyages)`
  },
  {
    title: "Les stations offrant au moins 2 moyens de transport ",
    description: "Trouver les stations offrant au moins 2 moyens de transport et préciser la station et les moyens de transport offerts",
    requete: `SELECT 
    s.codeS AS code_station,
    s.nom AS nom_station,
    (SELECT LISTAGG(mt.abreviation, ', ') WITHIN GROUP (ORDER BY mt.abreviation)
     FROM MoyenTransport mt
     WHERE REF(mt) IN (SELECT COLUMN_VALUE FROM TABLE(s.moyens))) AS moyens_transport,
    CARDINALITY(s.moyens) AS nombre_moyens
FROM Station s
WHERE CARDINALITY(s.moyens) >= 2
ORDER BY nombre_moyens DESC`
  }
];

export default function SQL3Page() {
  const [selected, setSelected] = useState(null);
  const [result, setResult] = useState(null);

  const executeRequete = async () => {
    if (!selected) return;

    const response = await fetch('http://localhost:3000/sql3', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ requete: selected.requete })
    });

    const data = await response.json();
    setResult(data);
  };

  return (
    <div className="page-container">
      {!selected && (
        <div className="cards-container">
          {questions.map((q, i) => (
            <QuestionCard key={i} question={q} onSelect={setSelected} />
          ))}
        </div>
      )}

      {selected && (
        <div className="selected-container">
          <div className="left-half">
            <img src={dzImage} alt="MongoDB Illustration" />
          </div>
          <div className="right-half">
            <h2>{selected.title}</h2>
            <pre>{selected.requete}</pre>
            <div>
              <button className="action-button" onClick={executeRequete}>Exécuter la requête</button>
              <button className="action-button" onClick={() => { setSelected(null); setResult(null); }}>Retour</button>
            </div>
            {result && (
              <div style={{ marginTop: '1rem', background: '#fff', color: '#000', padding: '1rem', borderRadius: '10px' }}>
                <h4>Résultats :</h4>
                <pre>{JSON.stringify(result, null, 2)}</pre>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
