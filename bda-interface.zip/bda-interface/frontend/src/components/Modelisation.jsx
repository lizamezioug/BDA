import React from "react";
import Navbar from "../components/Navbar";
import classeImage from "../assets/classe.png"; // Vérifie bien le chemin

const modele = {
  "_id": "ObjectId(\"...\")",
  "numeroV": 1,
  "dateVoyage": "2025-01-05T00:00:00Z",
  "heureDebut": "07:00",
  "duree": "00:45",
  "sens": "Aller",
  "nombreVoyageurs": 42,
  "observation": "Normal",
  "navette": {
    "numeroN": 1,
    "marque": "Hyundai Algérie",
    "anneeMiseEnCirculation": 2022,
    "ligne": {
      "codeL": "B001",
      "stationDepart": "Alger Centre",
      "stationArrivee": "El Harrach",
      "moyenTransport": {
        "abreviation": "BUS",
        "heureOuverture": "05:00",
        "heureFermeture": "23:00",
        "NbMoyenVoyageurs": 50
      },
      "troncons": [
        {
          "numeroT": 1,
          "stationDebut": "Alger Centre",
          "stationFin": "Hussein Dey",
          "longueur": 5.3
        },
        {
          "numeroT": 2,
          "stationDebut": "Hussein Dey",
          "stationFin": "El Harrach",
          "longueur": 4.2
        }
      ]
    }
  },
  "stations": [
    {
      "codeS": "S001",
      "nom": "Alger Centre",
      "latitude": 36.7539,
      "longitude": 3.0589,
      "type": "principale"
    },
    {
      "codeS": "S004",
      "nom": "Hussein Dey",
      "latitude": 36.7400,
      "longitude": 3.1078,
      "type": "principale"
    },
    {
      "codeS": "S002",
      "nom": "El Harrach",
      "latitude": 36.7167,
      "longitude": 3.1500,
      "type": "principale"
    }
  ]
};

const Modelisation = () => {
  return (
    <div style={{ 
      backgroundColor: "#0a1528", 
      minHeight: "100vh",
      width: "100%",
      margin: 0,
      padding: 0,
    

      
    }}>
      <Navbar />
      
      {/* Container principal sur toute la largeur */}
      <div style={{
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        width: "100%",
        margin: "80px 0 0", // Seulement marge supérieure
        padding: "0 30px", // Padding horizontal pour éviter le contact avec les bords
        boxSizing: "border-box" // Inclut padding dans la largeur
      }}>
        <h2 style={{ 
          textAlign: "center", 
          marginBottom: "30px",
          fontSize: "28px",
          color: "#e6f1ff"
        }}>
          Modélisation du Voyage
        </h2>
        
        {/* Container flex pour disposition horizontale sur toute la largeur */}
        <div style={{
          display: "flex",
          width: "100%",
          gap: "20px",
          justifyContent: "space-between", // Distribue l'espace entre les éléments
          alignItems: "stretch",
          flexWrap: "nowrap",
          height: "calc(100vh - 180px)" // Hauteur fixe pour remplir l'écran
        }}>
          {/* Div de la modélisation orientée document (à gauche) */}
          <div style={{ 
            width: "38%",
            // backgroundColor: "#05101f",
            borderRadius: "6px",
            padding: "15px",
            // boxShadow: "0 4px 8px rgba(0, 0, 0, 0.3)",
            color: "#c5e4fd",
            overflowY: "auto",
            height: "100%"
          }}>
            <h3 style={{ 
              textAlign: "center", 
              marginBottom: "15px",
              color: "white",
              
            }}>
              Modélisation orientée document
            </h3>
            
            <pre style={{ 
              backgroundColor: "transparent",
              color: "#90CAF9",
              padding: "5px", 
              margin: 0,
              overflowX: "auto", 
              maxWidth: "100%",
              fontSize: "20px",
              fontFamily: "monospace"
            }}>
              {JSON.stringify(modele, null, 2)}
            </pre>
          </div>
          
          {/* Div du diagramme de classes (à droite) */}
          <div style={{ 
            width: "90%",
            
            borderRadius: "6px",
            padding: "15px",
            display: "flex",
            flexDirection: "column",
            boxShadow: "0 4px 8px rgba(0, 0, 0, 0.3)",
            height: "100%"
          }}>
            <h3 style={{ 
              textAlign: "center", 
              marginBottom: "15px",
              color: "#90CAF9"
            }}>
              Diagramme de classes
            </h3>
            
            <div style={{
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              flexGrow: 1,
              overflow: "hidden",
              backgroundColor: "#ffffff", // Fond blanc pour le contenu uniquement
              borderRadius: "4px",
              padding: "10px"
            }}>
              <img 
                src={classeImage} 
                alt="Diagramme de classes" 
                style={{ 
                  width: "98%", 
                  height: "auto",
                  objectFit: "contain",
                  maxHeight: "100%"
                }} 
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Modelisation;